<?php if (!defined('ABSPATH')) die('not allowed');


class mymail_statistics {

	public function __construct() {

		
	}
}


?>